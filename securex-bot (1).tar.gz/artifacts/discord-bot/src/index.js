const { Client, GatewayIntentBits, Collection, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const http = require('http');

const PORT = process.env.PORT || 3000;
http.createServer((req, res) => {
  res.writeHead(200);
  res.end('SecureX Bot is running! 🤖');
}).listen(PORT, () => {
  console.log(`🌐 Web server running on port ${PORT}`);
});

const token = process.env.DISCORD_TOKEN;
if (!token) {
  console.error('❌ Missing DISCORD_TOKEN environment variable!');
  process.exit(1);
}

const PREFIX = '!';

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.GuildBans,
    GatewayIntentBits.GuildModeration,
    GatewayIntentBits.GuildIntegrations,
    GatewayIntentBits.GuildWebhooks,
  ]
});

client.commands = new Collection();
client.PREFIX = PREFIX;

const commandsPath = path.join(__dirname, 'commands');
const commandFiles = fs.readdirSync(commandsPath).filter(f => f.endsWith('.js'));

for (const file of commandFiles) {
  const mod = require(path.join(commandsPath, file));
  const cmds = mod.commands || mod;
  if (Array.isArray(cmds)) {
    for (const cmd of cmds) {
      if (cmd.name) {
        client.commands.set(cmd.name, cmd);
        if (cmd.aliases) cmd.aliases.forEach(a => client.commands.set(a, cmd));
      }
    }
  }
}

const autoroleModule = require('./commands/autorole');
const autonickModule = require('./commands/autonick');
const automodModule = require('./commands/automod');
const autoresponderModule = require('./commands/autoresponder');
const antinukeModule = require('./commands/antinuke');
const giveawayModule = require('./commands/giveaway');

require('./events/logging')(client);
antinukeModule.setupAntiNuke(client);
giveawayModule.setupGiveawayButtons(client);

client.once('clientReady', () => {
  console.log(`✅ SecureX Bot is online as ${client.user.tag}`);
  console.log(`📊 Serving ${client.guilds.cache.size} server(s)`);
  console.log(`🔧 Prefix: ${PREFIX}`);
  client.user.setPresence({
    activities: [{ name: `!help | SecureX`, type: 3 }],
    status: 'online'
  });
});

client.on('messageCreate', async message => {
  if (message.author.bot || !message.guild) return;

  const mentioned = message.mentions.users.has(client.user.id) && !message.content.startsWith(PREFIX);
  if (mentioned) {
    const embed = new EmbedBuilder()
      .setColor(0x00B0F4)
      .setTitle('💙 Hello!')
      .setDescription(`I'm **SecureX**, a multi-purpose Discord bot 🤖\n\n🔵 Prefix: \`${PREFIX}\`\n🔵 Type \`${PREFIX}help\` to see all commands`)
      .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
      .setFooter({ text: 'SecureX Bot', iconURL: client.user.displayAvatarURL() })
      .setTimestamp();
    return message.reply({ embeds: [embed] });
  }

  if (!message.content.startsWith(PREFIX)) {
    await automodModule.handleMessage(message);
    await autoresponderModule.handleMessage(message);
    return;
  }

  const args = message.content.slice(PREFIX.length).trim().split(/ +/);
  const commandName = args.shift().toLowerCase();
  if (!commandName) return;

  const command = client.commands.get(commandName);
  if (!command) return;

  try {
    await command.execute(message, args, client);
  } catch (err) {
    console.error(`[Error] Command: ${commandName}`, err);
    message.reply('❌ An error occurred while running this command!').catch(() => {});
  }
});

client.on('guildMemberAdd', async member => {
  await autoroleModule.onMemberJoin(member);
  await autonickModule.onMemberJoin(member);
});

client.on('error', err => console.error('[Discord Error]', err));

client.login(token).catch(err => {
  console.error('❌ Failed to login:', err.message);
  process.exit(1);
});
