const fs = require('fs');
const path = require('path');

const dataDir = path.join(__dirname, '../../data');

if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

function getFilePath(name) {
  return path.join(dataDir, `${name}.json`);
}

function read(name) {
  const fp = getFilePath(name);
  if (!fs.existsSync(fp)) return {};
  try { return JSON.parse(fs.readFileSync(fp, 'utf8')); } catch { return {}; }
}

function write(name, data) {
  fs.writeFileSync(getFilePath(name), JSON.stringify(data, null, 2));
}

function getGuild(file, guildId) {
  const data = read(file);
  if (!data[guildId]) data[guildId] = {};
  return data[guildId];
}

function setGuild(file, guildId, guildData) {
  const data = read(file);
  data[guildId] = guildData;
  write(file, data);
}

module.exports = { read, write, getGuild, setGuild };
