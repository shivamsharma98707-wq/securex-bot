const { EmbedBuilder, AuditLogEvent } = require('discord.js');
const { getGuild } = require('../utils/db');
const colors = require('../utils/colors');

function send(client, guildId, embed) {
  const cfg = getGuild('logging', guildId);
  if (!cfg.channelId) return;
  const ch = client.channels.cache.get(cfg.channelId);
  if (ch) ch.send({ embeds: [embed] }).catch(() => {});
}

module.exports = function setupLogging(client) {
  client.on('messageDelete', msg => {
    if (!msg.guild || msg.author?.bot) return;
    send(client, msg.guild.id, new EmbedBuilder().setColor(colors.ERROR).setTitle('🗑️ Message Deleted')
      .addFields({ name: 'Author', value: `${msg.author?.tag || 'Unknown'} (${msg.author?.id || '?'})`, inline: true }, { name: 'Channel', value: `${msg.channel}`, inline: true }, { name: 'Content', value: msg.content?.slice(0, 1024) || '*No content*' }).setTimestamp());
  });

  client.on('messageUpdate', (old, newMsg) => {
    if (!old.guild || old.author?.bot || old.content === newMsg.content) return;
    send(client, old.guild.id, new EmbedBuilder().setColor(colors.WARNING).setTitle('✏️ Message Edited')
      .addFields({ name: 'Author', value: `${old.author?.tag}`, inline: true }, { name: 'Channel', value: `${old.channel}`, inline: true }, { name: 'Before', value: old.content?.slice(0, 512) || '*empty*' }, { name: 'After', value: newMsg.content?.slice(0, 512) || '*empty*' }).setTimestamp());
  });

  client.on('guildMemberAdd', member => {
    send(client, member.guild.id, new EmbedBuilder().setColor(colors.SUCCESS).setTitle('📥 Member Joined')
      .setThumbnail(member.user.displayAvatarURL())
      .addFields({ name: 'User', value: `${member.user.tag} (${member.user.id})`, inline: true }, { name: 'Account Created', value: `<t:${Math.floor(member.user.createdTimestamp / 1000)}:R>`, inline: true }, { name: 'Member Count', value: `${member.guild.memberCount}`, inline: true }).setTimestamp());
  });

  client.on('guildMemberRemove', member => {
    send(client, member.guild.id, new EmbedBuilder().setColor(colors.ERROR).setTitle('📤 Member Left')
      .setThumbnail(member.user.displayAvatarURL())
      .addFields({ name: 'User', value: `${member.user.tag} (${member.user.id})`, inline: true }, { name: 'Joined At', value: member.joinedAt ? `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>` : 'Unknown', inline: true }).setTimestamp());
  });

  client.on('guildMemberUpdate', (old, newMember) => {
    if (old.nickname !== newMember.nickname) {
      send(client, newMember.guild.id, new EmbedBuilder().setColor(colors.INFO).setTitle('✏️ Nickname Changed')
        .addFields({ name: 'User', value: `${newMember.user.tag}`, inline: true }, { name: 'Before', value: old.nickname || 'None', inline: true }, { name: 'After', value: newMember.nickname || 'None', inline: true }).setTimestamp());
    }
  });

  client.on('channelCreate', channel => {
    if (!channel.guild) return;
    send(client, channel.guild.id, new EmbedBuilder().setColor(colors.SUCCESS).setTitle('📢 Channel Created')
      .addFields({ name: 'Channel', value: `${channel} (${channel.name})`, inline: true }, { name: 'Type', value: `${channel.type}`, inline: true }).setTimestamp());
  });

  client.on('channelDelete', channel => {
    if (!channel.guild) return;
    send(client, channel.guild.id, new EmbedBuilder().setColor(colors.ERROR).setTitle('🗑️ Channel Deleted')
      .addFields({ name: 'Name', value: channel.name, inline: true }, { name: 'Type', value: `${channel.type}`, inline: true }).setTimestamp());
  });

  client.on('roleCreate', role => {
    send(client, role.guild.id, new EmbedBuilder().setColor(colors.SUCCESS).setTitle('🎭 Role Created')
      .addFields({ name: 'Role', value: `${role} (${role.name})`, inline: true }, { name: 'Color', value: role.hexColor, inline: true }).setTimestamp());
  });

  client.on('roleDelete', role => {
    send(client, role.guild.id, new EmbedBuilder().setColor(colors.ERROR).setTitle('🗑️ Role Deleted')
      .addFields({ name: 'Name', value: role.name, inline: true }).setTimestamp());
  });
};
