const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuild, setGuild } = require('../utils/db');

module.exports.commands = [
  {
    name: 'ar',
    aliases: ['autoresponder', 'respond'],
    description: 'Auto response triggers',
    execute: async (message, args) => {
      if (!message.member.permissions.has(PermissionFlagsBits.ManageMessages)) return message.reply('❌ You need `Manage Messages` permission!');
      const sub = args[0]?.toLowerCase();
      const cfg = getGuild('autoresponder', message.guildId);
      if (!cfg.triggers) cfg.triggers = {};

      if (sub === 'add') {
        const content = args.slice(1).join(' ');
        const parts = content.split('|');
        if (parts.length < 2) return message.reply('❌ Usage: `!ar add <trigger> | <response>`\nExample: `!ar add hello | Hello there!`');
        const trigger = parts[0].trim().toLowerCase();
        const response = parts.slice(1).join('|').trim();
        cfg.triggers[trigger] = response;
        setGuild('autoresponder', message.guildId, cfg);
        await message.reply({ embeds: [new EmbedBuilder().setColor(0x57F287).setTitle('💬 Autoresponder Added').addFields({ name: 'Trigger', value: `\`${trigger}\`` }, { name: 'Response', value: response }).setTimestamp()] });
      } else if (sub === 'remove' || sub === 'delete') {
        const trigger = args.slice(1).join(' ').toLowerCase();
        if (!trigger) return message.reply('❌ Usage: `!ar remove <trigger>`');
        delete cfg.triggers[trigger];
        setGuild('autoresponder', message.guildId, cfg);
        await message.reply({ embeds: [new EmbedBuilder().setColor(0x57F287).setTitle('✅ Trigger Removed').setDescription(`Trigger \`${trigger}\` removed.`).setTimestamp()] });
      } else if (sub === 'list') {
        const list = Object.keys(cfg.triggers);
        await message.reply({ embeds: [new EmbedBuilder().setColor(0x5865F2).setTitle('💬 Auto Responders').setDescription(list.length ? list.map(t => `\`${t}\` → ${cfg.triggers[t]}`).join('\n').slice(0, 2048) : 'No triggers set.').setTimestamp()] });
      } else {
        await message.reply('❌ Usage: `!ar add <trigger> | <response>` | `!ar remove <trigger>` | `!ar list`');
      }
    }
  }
];

module.exports.handleMessage = async function(message) {
  if (!message.guild || message.author.bot) return;
  const cfg = getGuild('autoresponder', message.guild.id);
  if (!cfg.triggers) return;
  const lower = message.content.toLowerCase();
  for (const [trigger, response] of Object.entries(cfg.triggers)) {
    if (lower.includes(trigger)) {
      await message.reply({ content: response }).catch(() => {});
      break;
    }
  }
};
