const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuild, setGuild } = require('../utils/db');

module.exports.commands = [
  {
    name: 'logging',
    aliases: ['log'],
    description: 'Configure server logging',
    execute: async (message, args) => {
      if (!message.member.permissions.has(PermissionFlagsBits.ManageGuild)) return message.reply('❌ You need `Manage Server` permission!');
      const sub = args[0]?.toLowerCase();
      const cfg = getGuild('logging', message.guildId);
      if (sub === 'set') {
        const ch = message.mentions.channels.first();
        if (!ch) return message.reply('❌ Usage: `!logging set #channel`');
        cfg.channelId = ch.id;
        setGuild('logging', message.guildId, cfg);
        await message.reply({ embeds: [new EmbedBuilder().setColor(0x57F287).setTitle('📋 Logging Enabled').setDescription(`Log channel set to ${ch}`).setTimestamp()] });
      } else if (sub === 'off' || sub === 'disable') {
        cfg.channelId = null;
        setGuild('logging', message.guildId, cfg);
        await message.reply({ embeds: [new EmbedBuilder().setColor(0xED4245).setTitle('📋 Logging Disabled').setTimestamp()] });
      } else if (sub === 'status') {
        const ch = cfg.channelId ? `<#${cfg.channelId}>` : 'Not set';
        await message.reply({ embeds: [new EmbedBuilder().setColor(0x5865F2).setTitle('📋 Logging Status').addFields({ name: 'Status', value: cfg.channelId ? '✅ Enabled' : '❌ Disabled', inline: true }, { name: 'Channel', value: ch, inline: true }).setTimestamp()] });
      } else {
        await message.reply('❌ Usage: `!logging set #channel` | `!logging off` | `!logging status`');
      }
    }
  }
];
