const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuild, setGuild } = require('../utils/db');
const ms = require('ms');

function hasPerms(message, perm) {
  if (!message.member.permissions.has(perm)) {
    message.reply(`❌ You need \`${perm}\` permission to use this command!`);
    return false;
  }
  return true;
}

function logAction(client, guildId, embed) {
  const cfg = getGuild('logging', guildId);
  if (cfg.channelId) {
    const ch = client.channels.cache.get(cfg.channelId);
    if (ch) ch.send({ embeds: [embed] }).catch(() => {});
  }
}

module.exports.commands = [
  {
    name: 'ban',
    description: 'Ban a member',
    execute: async (message, args) => {
      if (!hasPerms(message, PermissionFlagsBits.BanMembers)) return;
      const user = message.mentions.users.first();
      if (!user) return message.reply('❌ Mention a user to ban!\n**Usage:** `!ban @user [reason]`');
      const reason = args.slice(1).join(' ') || 'No reason provided';
      const member = message.guild.members.cache.get(user.id);
      if (member && !member.bannable) return message.reply('❌ I cannot ban this user!');
      await message.guild.members.ban(user.id, { reason });
      const embed = new EmbedBuilder().setColor(0xED4245).setTitle('🔨 Member Banned')
        .addFields({ name: 'User', value: `${user.tag} (${user.id})`, inline: true }, { name: 'Moderator', value: message.author.tag, inline: true }, { name: 'Reason', value: reason }).setTimestamp();
      await message.reply({ embeds: [embed] });
      logAction(message.client, message.guildId, embed);
    }
  },
  {
    name: 'unban',
    description: 'Unban a user',
    execute: async (message, args) => {
      if (!hasPerms(message, PermissionFlagsBits.BanMembers)) return;
      const userId = args[0];
      if (!userId) return message.reply('❌ Provide a user ID!\n**Usage:** `!unban <userId> [reason]`');
      const reason = args.slice(1).join(' ') || 'No reason provided';
      try {
        await message.guild.members.unban(userId, reason);
        await message.reply({ embeds: [new EmbedBuilder().setColor(0x57F287).setTitle('✅ Member Unbanned').addFields({ name: 'User ID', value: userId }, { name: 'Reason', value: reason }).setTimestamp()] });
      } catch { message.reply('❌ User not found or not banned!'); }
    }
  },
  {
    name: 'kick',
    description: 'Kick a member',
    execute: async (message, args) => {
      if (!hasPerms(message, PermissionFlagsBits.KickMembers)) return;
      const user = message.mentions.users.first();
      if (!user) return message.reply('❌ Mention a user to kick!\n**Usage:** `!kick @user [reason]`');
      const reason = args.slice(1).join(' ') || 'No reason provided';
      const member = message.guild.members.cache.get(user.id);
      if (!member) return message.reply('❌ User not in this server!');
      if (!member.kickable) return message.reply('❌ I cannot kick this user!');
      await member.kick(reason);
      const embed = new EmbedBuilder().setColor(0xFEE75C).setTitle('👢 Member Kicked')
        .addFields({ name: 'User', value: `${user.tag}`, inline: true }, { name: 'Moderator', value: message.author.tag, inline: true }, { name: 'Reason', value: reason }).setTimestamp();
      await message.reply({ embeds: [embed] });
      logAction(message.client, message.guildId, embed);
    }
  },
  {
    name: 'mute',
    aliases: ['timeout'],
    description: 'Mute/Timeout a member',
    execute: async (message, args) => {
      if (!hasPerms(message, PermissionFlagsBits.ModerateMembers)) return;
      const user = message.mentions.users.first();
      if (!user || !args[1]) return message.reply('❌ Usage: `!mute @user <duration> [reason]`\nExample: `!mute @user 10m spamming`');
      const duration = args[1];
      const reason = args.slice(2).join(' ') || 'No reason provided';
      const member = message.guild.members.cache.get(user.id);
      if (!member) return message.reply('❌ User not in server!');
      const msTime = ms(duration);
      if (!msTime) return message.reply('❌ Invalid duration! Use: `10m`, `1h`, `1d`');
      await member.timeout(msTime, reason);
      const embed = new EmbedBuilder().setColor(0xFEE75C).setTitle('⏳ Member Muted')
        .addFields({ name: 'User', value: `${user.tag}`, inline: true }, { name: 'Duration', value: duration, inline: true }, { name: 'Reason', value: reason }).setTimestamp();
      await message.reply({ embeds: [embed] });
      logAction(message.client, message.guildId, embed);
    }
  },
  {
    name: 'unmute',
    aliases: ['untimeout'],
    description: 'Unmute a member',
    execute: async (message, args) => {
      if (!hasPerms(message, PermissionFlagsBits.ModerateMembers)) return;
      const user = message.mentions.users.first();
      if (!user) return message.reply('❌ Usage: `!unmute @user`');
      const member = message.guild.members.cache.get(user.id);
      if (!member) return message.reply('❌ User not in server!');
      await member.timeout(null);
      await message.reply({ embeds: [new EmbedBuilder().setColor(0x57F287).setTitle('✅ Member Unmuted').setDescription(`${user.tag} has been unmuted.`).setTimestamp()] });
    }
  },
  {
    name: 'warn',
    description: 'Warn a member',
    execute: async (message, args) => {
      if (!hasPerms(message, PermissionFlagsBits.ModerateMembers)) return;
      const user = message.mentions.users.first();
      if (!user || args.length < 2) return message.reply('❌ Usage: `!warn @user <reason>`');
      const reason = args.slice(1).join(' ');
      const warns = getGuild('warnings', message.guildId);
      if (!warns[user.id]) warns[user.id] = [];
      warns[user.id].push({ reason, moderator: message.author.tag, time: Date.now() });
      setGuild('warnings', message.guildId, warns);
      const embed = new EmbedBuilder().setColor(0xFEE75C).setTitle('⚠️ Member Warned')
        .addFields({ name: 'User', value: `${user.tag}`, inline: true }, { name: 'Warnings', value: `${warns[user.id].length}`, inline: true }, { name: 'Reason', value: reason }).setTimestamp();
      await message.reply({ embeds: [embed] });
      logAction(message.client, message.guildId, embed);
    }
  },
  {
    name: 'warnings',
    aliases: ['warns'],
    description: 'View warnings of a member',
    execute: async (message, args) => {
      if (!hasPerms(message, PermissionFlagsBits.ModerateMembers)) return;
      const user = message.mentions.users.first() || message.author;
      const warns = getGuild('warnings', message.guildId);
      const userWarns = warns[user.id] || [];
      await message.reply({ embeds: [new EmbedBuilder().setColor(0x5865F2).setTitle(`⚠️ Warnings — ${user.tag}`).setDescription(userWarns.length ? userWarns.map((w, i) => `**${i+1}.** ${w.reason} — *${w.moderator}*`).join('\n') : 'No warnings.').setTimestamp()] });
    }
  },
  {
    name: 'clearwarns',
    aliases: ['delwarns'],
    description: 'Clear warnings of a member',
    execute: async (message, args) => {
      if (!hasPerms(message, PermissionFlagsBits.ModerateMembers)) return;
      const user = message.mentions.users.first();
      if (!user) return message.reply('❌ Usage: `!clearwarns @user`');
      const warns = getGuild('warnings', message.guildId);
      warns[user.id] = [];
      setGuild('warnings', message.guildId, warns);
      await message.reply({ embeds: [new EmbedBuilder().setColor(0x57F287).setTitle('✅ Warnings Cleared').setDescription(`All warnings cleared for ${user.tag}.`).setTimestamp()] });
    }
  },
  {
    name: 'purge',
    aliases: ['clear'],
    description: 'Delete messages in bulk',
    execute: async (message, args) => {
      if (!hasPerms(message, PermissionFlagsBits.ManageMessages)) return;
      const amount = parseInt(args[0]);
      if (!amount || amount < 1 || amount > 100) return message.reply('❌ Usage: `!purge <1-100> [@user]`');
      await message.delete().catch(() => {});
      const user = message.mentions.users.first();
      let msgs = await message.channel.messages.fetch({ limit: amount });
      if (user) msgs = msgs.filter(m => m.author.id === user.id);
      const deleted = await message.channel.bulkDelete(msgs, true);
      const reply = await message.channel.send(`✅ Deleted **${deleted.size}** messages.`);
      setTimeout(() => reply.delete().catch(() => {}), 4000);
    }
  },
  {
    name: 'slowmode',
    description: 'Set channel slowmode',
    execute: async (message, args) => {
      if (!hasPerms(message, PermissionFlagsBits.ManageChannels)) return;
      const sec = parseInt(args[0]);
      if (isNaN(sec) || sec < 0 || sec > 21600) return message.reply('❌ Usage: `!slowmode <0-21600>`');
      await message.channel.setRateLimitPerUser(sec);
      await message.reply({ embeds: [new EmbedBuilder().setColor(0x57F287).setTitle('⏱️ Slowmode Updated').setDescription(sec === 0 ? 'Slowmode disabled.' : `Slowmode set to **${sec}** seconds.`).setTimestamp()] });
    }
  },
  {
    name: 'nick',
    description: "Change a member's nickname",
    execute: async (message, args) => {
      if (!hasPerms(message, PermissionFlagsBits.ManageNicknames)) return;
      const user = message.mentions.users.first();
      if (!user) return message.reply('❌ Usage: `!nick @user <nickname>` or `!nick @user reset`');
      const member = message.guild.members.cache.get(user.id);
      if (!member) return message.reply('❌ User not found!');
      const nick = args.slice(1).join(' ');
      const newNick = nick === 'reset' ? null : nick || null;
      await member.setNickname(newNick);
      await message.reply({ embeds: [new EmbedBuilder().setColor(0x57F287).setTitle('✏️ Nickname Updated').setDescription(`${user.tag}'s nickname → **${newNick || 'Reset'}**`).setTimestamp()] });
    }
  }
];
