const { EmbedBuilder, PermissionFlagsBits, ButtonBuilder, ButtonStyle, ActionRowBuilder } = require('discord.js');
const { read, write } = require('../utils/db');
const ms = require('ms');

function save(data) { write('giveaways', data); }
function load() { return read('giveaways'); }

async function endGiveaway(client, msgId) {
  const giveaways = load();
  const g = giveaways[msgId];
  if (!g || g.ended) return;
  g.ended = true;
  save(giveaways);
  const channel = client.channels.cache.get(g.channelId);
  if (!channel) return;
  const msg = await channel.messages.fetch(msgId).catch(() => null);
  if (!msg) return;
  const winners = pickWinners(g.entries, g.winners);
  const embed = new EmbedBuilder().setColor(0xEB6234).setTitle('🎉 GIVEAWAY ENDED!')
    .setDescription(`**${g.prize}**\n\n${winners.length ? `🏆 Winner(s): ${winners.map(w => `<@${w}>`).join(', ')}` : '❌ No entries!'}`)
    .setFooter({ text: `Hosted by ${g.host}` }).setTimestamp();
  const btn = new ButtonBuilder().setCustomId('giveaway_enter').setLabel('🎉 Ended').setStyle(ButtonStyle.Secondary).setDisabled(true);
  await msg.edit({ embeds: [embed], components: [new ActionRowBuilder().addComponents(btn)] });
  if (winners.length) await channel.send({ content: `🎉 Congratulations ${winners.map(w => `<@${w}>`).join(', ')}! You won **${g.prize}**!` });
}

function pickWinners(entries, count) {
  const pool = [...entries], winners = [];
  for (let i = 0; i < Math.min(count, pool.length); i++) {
    winners.push(pool.splice(Math.floor(Math.random() * pool.length), 1)[0]);
  }
  return winners;
}

module.exports.commands = [
  {
    name: 'gstart',
    aliases: ['gcreate'],
    description: 'Start a giveaway',
    execute: async (message, args) => {
      if (!message.member.permissions.has(PermissionFlagsBits.ManageGuild)) return message.reply('❌ You need `Manage Server` permission!');
      if (args.length < 3) return message.reply('❌ Usage: `!gstart <duration> <winners> <prize>`\nExample: `!gstart 1h 1 Nitro`');
      const duration = args[0];
      const winners = parseInt(args[1]);
      const prize = args.slice(2).join(' ');
      const msTime = ms(duration);
      if (!msTime) return message.reply('❌ Invalid duration! Use: `10m`, `1h`, `1d`');
      if (isNaN(winners) || winners < 1) return message.reply('❌ Invalid winner count!');
      const endTime = Date.now() + msTime;
      const embed = new EmbedBuilder().setColor(0xEB6234).setTitle('🎉 GIVEAWAY!')
        .setDescription(`**${prize}**\n\nClick the button below to enter!\n\n🏆 Winners: **${winners}**\n⏰ Ends: <t:${Math.floor(endTime / 1000)}:R>`)
        .setFooter({ text: `Hosted by ${message.author.tag}` }).setTimestamp(endTime);
      const btn = new ButtonBuilder().setCustomId('giveaway_enter').setLabel('🎉 Enter Giveaway').setStyle(ButtonStyle.Primary);
      const msg = await message.channel.send({ embeds: [embed], components: [new ActionRowBuilder().addComponents(btn)] });
      const giveaways = load();
      giveaways[msg.id] = { prize, winners, endTime, channelId: message.channelId, guildId: message.guildId, host: message.author.tag, entries: [], ended: false };
      save(giveaways);
      await message.reply(`✅ Giveaway started! [Jump to giveaway](${msg.url})`);
      setTimeout(() => endGiveaway(message.client, msg.id), msTime);
    }
  },
  {
    name: 'gend',
    description: 'End a giveaway early',
    execute: async (message, args) => {
      if (!message.member.permissions.has(PermissionFlagsBits.ManageGuild)) return message.reply('❌ You need `Manage Server` permission!');
      if (!args[0]) return message.reply('❌ Usage: `!gend <messageId>`');
      await endGiveaway(message.client, args[0]);
      await message.reply('✅ Giveaway ended!');
    }
  },
  {
    name: 'greroll',
    description: 'Reroll a giveaway',
    execute: async (message, args) => {
      if (!message.member.permissions.has(PermissionFlagsBits.ManageGuild)) return message.reply('❌ You need `Manage Server` permission!');
      if (!args[0]) return message.reply('❌ Usage: `!greroll <messageId>`');
      const giveaways = load();
      const g = giveaways[args[0]];
      if (!g || !g.ended) return message.reply('❌ Giveaway not found or still active!');
      if (!g.entries.length) return message.reply('❌ No entries!');
      const winners = pickWinners(g.entries, g.winners);
      await message.reply({ content: `🎉 New winner(s): ${winners.map(w => `<@${w}>`).join(', ')}! Congratulations for **${g.prize}**!` });
    }
  },
  {
    name: 'glist',
    description: 'List active giveaways',
    execute: async (message) => {
      const giveaways = load();
      const active = Object.entries(giveaways).filter(([, g]) => g.guildId === message.guildId && !g.ended);
      if (!active.length) return message.reply({ embeds: [new EmbedBuilder().setColor(0xEB6234).setTitle('🎉 Active Giveaways').setDescription('No active giveaways.').setTimestamp()] });
      await message.reply({ embeds: [new EmbedBuilder().setColor(0xEB6234).setTitle('🎉 Active Giveaways').setDescription(active.map(([id, g]) => `**${g.prize}** — Ends <t:${Math.floor(g.endTime / 1000)}:R>`).join('\n')).setTimestamp()] });
    }
  }
];

module.exports.setupGiveawayButtons = function(client) {
  client.on('interactionCreate', async interaction => {
    if (!interaction.isButton() || interaction.customId !== 'giveaway_enter') return;
    const giveaways = load();
    const g = giveaways[interaction.message.id];
    if (!g || g.ended) return interaction.reply({ content: '❌ This giveaway has ended!', ephemeral: true });
    if (g.entries.includes(interaction.user.id)) return interaction.reply({ content: '✅ You are already entered!', ephemeral: true });
    g.entries.push(interaction.user.id);
    save(giveaways);
    await interaction.reply({ content: `✅ You entered the giveaway for **${g.prize}**! Good luck! 🎉 (${g.entries.length} total entries)`, ephemeral: true });
  });
};
