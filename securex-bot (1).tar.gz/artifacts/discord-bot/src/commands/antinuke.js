const { EmbedBuilder, PermissionFlagsBits, AuditLogEvent } = require('discord.js');
const { getGuild, setGuild } = require('../utils/db');

module.exports.commands = [
  {
    name: 'antinuke',
    aliases: ['an'],
    description: 'Anti-Nuke protection system',
    execute: async (message, args) => {
      if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) return message.reply('❌ You need `Administrator` permission!');
      const sub = args[0]?.toLowerCase();
      const cfg = getGuild('antinuke', message.guildId);
      if (!cfg.whitelist) cfg.whitelist = [];
      if (!cfg.whitelist.includes(message.guild.ownerId)) cfg.whitelist.push(message.guild.ownerId);

      if (sub === 'on' || sub === 'enable') {
        cfg.enabled = true;
        setGuild('antinuke', message.guildId, cfg);
        await message.reply({ embeds: [new EmbedBuilder().setColor(0x57F287).setTitle('🛡️ Anti-Nuke Enabled')
          .setDescription('Server is now protected!')
          .addFields({ name: '🔒 Protects Against', value: 'Mass Ban • Mass Kick • Mass Channel Delete\nMass Role Delete • Webhook Spam • Unauthorized Bot Add' })
          .setTimestamp()] });
      } else if (sub === 'off' || sub === 'disable') {
        cfg.enabled = false;
        setGuild('antinuke', message.guildId, cfg);
        await message.reply({ embeds: [new EmbedBuilder().setColor(0xED4245).setTitle('🛡️ Anti-Nuke Disabled').setTimestamp()] });
      } else if (sub === 'status') {
        const wl = cfg.whitelist.map(id => `<@${id}>`).join(', ') || 'None';
        await message.reply({ embeds: [new EmbedBuilder().setColor(0x5865F2).setTitle('🛡️ Anti-Nuke Status').addFields({ name: 'Status', value: cfg.enabled ? '✅ Enabled' : '❌ Disabled', inline: true }, { name: 'Whitelisted', value: wl }).setTimestamp()] });
      } else if (sub === 'whitelist') {
        const action = args[1]?.toLowerCase();
        const user = message.mentions.users.first();
        if (!user) return message.reply('❌ Usage: `!antinuke whitelist add/remove @user`');
        if (action === 'add') {
          if (!cfg.whitelist.includes(user.id)) cfg.whitelist.push(user.id);
          setGuild('antinuke', message.guildId, cfg);
          await message.reply({ embeds: [new EmbedBuilder().setColor(0x57F287).setTitle('✅ Whitelisted').setDescription(`${user.tag} added to Anti-Nuke whitelist.`).setTimestamp()] });
        } else if (action === 'remove') {
          cfg.whitelist = cfg.whitelist.filter(id => id !== user.id);
          setGuild('antinuke', message.guildId, cfg);
          await message.reply({ embeds: [new EmbedBuilder().setColor(0x57F287).setTitle('✅ Removed').setDescription(`${user.tag} removed from whitelist.`).setTimestamp()] });
        }
      } else {
        await message.reply('❌ Usage: `!antinuke on/off/status` | `!antinuke whitelist add/remove @user`');
      }
    }
  }
];

const actionCount = {};
function trackAction(guildId, userId, action) {
  const key = `${guildId}:${userId}:${action}`;
  if (!actionCount[key]) actionCount[key] = { count: 0, timer: null };
  actionCount[key].count++;
  clearTimeout(actionCount[key].timer);
  actionCount[key].timer = setTimeout(() => { delete actionCount[key]; }, 10000);
  return actionCount[key].count;
}

module.exports.setupAntiNuke = function(client) {
  const punish = async (guild, userId, reason) => {
    const cfg = getGuild('antinuke', guild.id);
    if (!cfg.enabled) return;
    if (cfg.whitelist?.includes(userId)) return;
    try {
      await guild.members.ban(userId, { reason: `[Anti-Nuke] ${reason}` });
      const logCfg = getGuild('logging', guild.id);
      if (logCfg.channelId) {
        const ch = guild.channels.cache.get(logCfg.channelId);
        if (ch) ch.send({ embeds: [new EmbedBuilder().setColor(0xED4245).setTitle('🛡️ Anti-Nuke Triggered').addFields({ name: 'User Banned', value: `<@${userId}> (${userId})` }, { name: 'Reason', value: reason }).setTimestamp()] });
      }
    } catch {}
  };

  client.on('guildBanAdd', async ban => {
    try {
      const logs = await ban.guild.fetchAuditLogs({ type: AuditLogEvent.MemberBanAdd, limit: 1 });
      const entry = logs.entries.first();
      if (!entry) return;
      if (trackAction(ban.guild.id, entry.executor.id, 'ban') >= 3) await punish(ban.guild, entry.executor.id, 'Mass Ban detected');
    } catch {}
  });
  client.on('guildMemberRemove', async member => {
    try {
      const logs = await member.guild.fetchAuditLogs({ type: AuditLogEvent.MemberKick, limit: 1 });
      const entry = logs.entries.first();
      if (!entry || entry.target?.id !== member.id) return;
      if (trackAction(member.guild.id, entry.executor.id, 'kick') >= 3) await punish(member.guild, entry.executor.id, 'Mass Kick detected');
    } catch {}
  });
  client.on('channelDelete', async channel => {
    try {
      const logs = await channel.guild.fetchAuditLogs({ type: AuditLogEvent.ChannelDelete, limit: 1 });
      const entry = logs.entries.first();
      if (!entry) return;
      if (trackAction(channel.guild.id, entry.executor.id, 'channelDelete') >= 2) await punish(channel.guild, entry.executor.id, 'Mass Channel Delete detected');
    } catch {}
  });
  client.on('roleDelete', async role => {
    try {
      const logs = await role.guild.fetchAuditLogs({ type: AuditLogEvent.RoleDelete, limit: 1 });
      const entry = logs.entries.first();
      if (!entry) return;
      if (trackAction(role.guild.id, entry.executor.id, 'roleDelete') >= 2) await punish(role.guild, entry.executor.id, 'Mass Role Delete detected');
    } catch {}
  });
  client.on('guildMemberAdd', async member => {
    if (!member.user.bot) return;
    try {
      const logs = await member.guild.fetchAuditLogs({ type: AuditLogEvent.BotAdd, limit: 1 });
      const entry = logs.entries.first();
      if (!entry) return;
      const cfg = getGuild('antinuke', member.guild.id);
      if (!cfg.enabled || cfg.whitelist?.includes(entry.executor.id)) return;
      await member.kick('[Anti-Nuke] Unauthorized bot');
      await punish(member.guild, entry.executor.id, 'Unauthorized bot addition');
    } catch {}
  });
};
