const { EmbedBuilder } = require('discord.js');

const eightBall = ['✅ It is certain.', '✅ Without a doubt.', '✅ Yes, definitely!', '✅ Most likely.', '✅ Signs point to yes.', '🤔 Ask again later.', '🤔 Cannot predict now.', '🤔 Concentrate and ask again.', '❌ Don\'t count on it.', '❌ My reply is no.', '❌ Very doubtful.', '❌ Outlook not so good.'];
const jokes = ['Why don\'t scientists trust atoms? Because they make up everything!', 'Why did the math book look sad? Because it had too many problems.', 'I told my wife she was drawing her eyebrows too high. She looked surprised.', 'What do you call cheese that isn\'t yours? Nacho cheese!', 'Why do cows wear bells? Because their horns don\'t work.'];
const roasts = ['You\'re not stupid, you just have bad luck thinking.', 'You\'re like a cloud. When you disappear, it\'s a beautiful day.', 'I\'d give you a nasty look but you\'ve already got one.', 'You\'re the reason God created the middle finger.'];
const compliments = ['You are absolutely amazing! 🌟', 'You make the world a better place! 🌈', 'Your smile could light up a whole room! 😊', 'You have an incredible ability to brighten anyone\'s day! ☀️', 'You\'re a true gem! 💎'];
const wyr = ['Would you rather fly or be invisible?', 'Would you rather live in the city or countryside?', 'Would you rather be always hot or always cold?', 'Would you rather have super strength or super speed?', 'Would you rather eat pizza or burgers forever?'];
const pick = arr => arr[Math.floor(Math.random() * arr.length)];

module.exports.commands = [
  {
    name: '8ball',
    aliases: ['8b'],
    description: 'Ask the magic 8-ball',
    execute: async (message, args) => {
      const q = args.join(' ');
      if (!q) return message.reply('❌ Usage: `!8ball <question>`');
      await message.reply({ embeds: [new EmbedBuilder().setColor(0x5865F2).setTitle('🎱 Magic 8-Ball').addFields({ name: '❓ Question', value: q }, { name: '🎱 Answer', value: pick(eightBall) }).setTimestamp()] });
    }
  },
  {
    name: 'coinflip',
    aliases: ['flip', 'coin'],
    description: 'Flip a coin',
    execute: async (message) => {
      await message.reply({ embeds: [new EmbedBuilder().setColor(0x5865F2).setTitle('🪙 Coin Flip').setDescription(Math.random() < 0.5 ? '🪙 **Heads!**' : '🪙 **Tails!**').setTimestamp()] });
    }
  },
  {
    name: 'dice',
    aliases: ['roll'],
    description: 'Roll a dice',
    execute: async (message, args) => {
      const sides = parseInt(args[0]) || 6;
      if (sides < 2 || sides > 100) return message.reply('❌ Sides must be between 2 and 100!');
      const roll = Math.floor(Math.random() * sides) + 1;
      await message.reply({ embeds: [new EmbedBuilder().setColor(0x5865F2).setTitle('🎲 Dice Roll').setDescription(`You rolled **${roll}** out of ${sides}!`).setTimestamp()] });
    }
  },
  {
    name: 'joke',
    description: 'Get a random joke',
    execute: async (message) => {
      await message.reply({ embeds: [new EmbedBuilder().setColor(0x5865F2).setTitle('😂 Random Joke').setDescription(pick(jokes)).setTimestamp()] });
    }
  },
  {
    name: 'roast',
    description: 'Roast someone',
    execute: async (message) => {
      const user = message.mentions.users.first();
      if (!user) return message.reply('❌ Usage: `!roast @user`');
      await message.reply({ embeds: [new EmbedBuilder().setColor(0xED4245).setTitle(`🔥 Roasting ${user.username}`).setDescription(pick(roasts)).setTimestamp()] });
    }
  },
  {
    name: 'compliment',
    aliases: ['comp'],
    description: 'Compliment someone',
    execute: async (message) => {
      const user = message.mentions.users.first();
      if (!user) return message.reply('❌ Usage: `!compliment @user`');
      await message.reply({ embeds: [new EmbedBuilder().setColor(0x57F287).setTitle(`💖 Complimenting ${user.username}`).setDescription(pick(compliments)).setTimestamp()] });
    }
  },
  {
    name: 'wyr',
    description: 'Would You Rather',
    execute: async (message) => {
      await message.reply({ embeds: [new EmbedBuilder().setColor(0x5865F2).setTitle('🤔 Would You Rather...').setDescription(pick(wyr)).setTimestamp()] });
    }
  },
  {
    name: 'rps',
    description: 'Rock Paper Scissors',
    execute: async (message, args) => {
      const choices = ['rock', 'paper', 'scissors'];
      const emojis = { rock: '🪨', paper: '📄', scissors: '✂️' };
      const userChoice = args[0]?.toLowerCase();
      if (!choices.includes(userChoice)) return message.reply('❌ Usage: `!rps <rock/paper/scissors>`');
      const botChoice = pick(choices);
      let result;
      if (userChoice === botChoice) result = '🤝 It\'s a tie!';
      else if ((userChoice === 'rock' && botChoice === 'scissors') || (userChoice === 'paper' && botChoice === 'rock') || (userChoice === 'scissors' && botChoice === 'paper')) result = '🎉 You win!';
      else result = '😔 Bot wins!';
      await message.reply({ embeds: [new EmbedBuilder().setColor(0x5865F2).setTitle('✊ Rock Paper Scissors').addFields({ name: 'Your Choice', value: `${emojis[userChoice]} ${userChoice}`, inline: true }, { name: 'Bot\'s Choice', value: `${emojis[botChoice]} ${botChoice}`, inline: true }, { name: 'Result', value: result }).setTimestamp()] });
    }
  }
];
