const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuild, setGuild } = require('../utils/db');

module.exports.commands = [
  {
    name: 'automod',
    aliases: ['am'],
    description: 'Auto moderation settings',
    execute: async (message, args) => {
      if (!message.member.permissions.has(PermissionFlagsBits.ManageGuild)) return message.reply('❌ You need `Manage Server` permission!');
      const sub = args[0]?.toLowerCase();
      const toggle = args[1]?.toLowerCase();
      const cfg = getGuild('automod', message.guildId);

      if (sub === 'badwords') {
        const enabled = toggle === 'on';
        cfg.badwords = cfg.badwords || {};
        cfg.badwords.enabled = enabled;
        const words = args.slice(2).join(' ');
        if (words) cfg.badwords.list = words.split(',').map(w => w.trim().toLowerCase());
        setGuild('automod', message.guildId, cfg);
        await message.reply({ embeds: [new EmbedBuilder().setColor(enabled ? 0x57F287 : 0xED4245).setTitle('⚙️ Bad Words Filter').addFields({ name: 'Status', value: enabled ? '✅ Enabled' : '❌ Disabled', inline: true }, { name: 'Words', value: cfg.badwords.list?.join(', ') || 'Using default list' }).setTimestamp()] });
      } else if (sub === 'antilink') {
        const enabled = toggle === 'on';
        cfg.antilink = { enabled };
        setGuild('automod', message.guildId, cfg);
        await message.reply({ embeds: [new EmbedBuilder().setColor(enabled ? 0x57F287 : 0xED4245).setTitle('🔗 Anti-Link').setDescription(enabled ? '✅ Links will now be deleted!' : '❌ Anti-link disabled.').setTimestamp()] });
      } else if (sub === 'antispam') {
        const enabled = toggle === 'on';
        const limit = parseInt(args[2]) || 5;
        cfg.antispam = { enabled, limit };
        setGuild('automod', message.guildId, cfg);
        await message.reply({ embeds: [new EmbedBuilder().setColor(enabled ? 0x57F287 : 0xED4245).setTitle('💬 Anti-Spam').addFields({ name: 'Status', value: enabled ? '✅ Enabled' : '❌ Disabled', inline: true }, { name: 'Limit', value: `${limit} msgs/5s`, inline: true }).setTimestamp()] });
      } else if (sub === 'caps') {
        const enabled = toggle === 'on';
        const percent = parseInt(args[2]) || 70;
        cfg.caps = { enabled, percent };
        setGuild('automod', message.guildId, cfg);
        await message.reply({ embeds: [new EmbedBuilder().setColor(enabled ? 0x57F287 : 0xED4245).setTitle('🔠 Caps Filter').addFields({ name: 'Status', value: enabled ? '✅ Enabled' : '❌ Disabled', inline: true }, { name: 'Trigger', value: `${percent}%`, inline: true }).setTimestamp()] });
      } else if (sub === 'status') {
        await message.reply({ embeds: [new EmbedBuilder().setColor(0x5865F2).setTitle('⚙️ Automod Status')
          .addFields(
            { name: '🤬 Bad Words', value: cfg.badwords?.enabled ? '✅ On' : '❌ Off', inline: true },
            { name: '🔗 Anti-Link', value: cfg.antilink?.enabled ? '✅ On' : '❌ Off', inline: true },
            { name: '💬 Anti-Spam', value: cfg.antispam?.enabled ? `✅ On (${cfg.antispam.limit}/5s)` : '❌ Off', inline: true },
            { name: '🔠 Caps Filter', value: cfg.caps?.enabled ? `✅ On (${cfg.caps.percent}%)` : '❌ Off', inline: true },
          ).setTimestamp()] });
      } else {
        await message.reply('❌ Usage:\n`!automod badwords on/off [word1,word2]`\n`!automod antilink on/off`\n`!automod antispam on/off [limit]`\n`!automod caps on/off [%]`\n`!automod status`');
      }
    }
  }
];

const spamTracker = {};
module.exports.handleMessage = async function(message) {
  if (!message.guild || message.author.bot) return;
  if (message.member?.permissions.has(PermissionFlagsBits.ManageMessages)) return;
  const cfg = getGuild('automod', message.guild.id);

  if (cfg.antilink?.enabled) {
    if (/(https?:\/\/|discord\.gg\/|discord\.com\/invite\/)/gi.test(message.content)) {
      await message.delete().catch(() => {});
      const w = await message.channel.send(`${message.author} ❌ Links are not allowed here!`);
      setTimeout(() => w.delete().catch(() => {}), 5000);
      return;
    }
  }

  if (cfg.badwords?.enabled && cfg.badwords.list?.length) {
    const lower = message.content.toLowerCase();
    if (cfg.badwords.list.some(w => lower.includes(w))) {
      await message.delete().catch(() => {});
      const w = await message.channel.send(`${message.author} ❌ That word is not allowed here!`);
      setTimeout(() => w.delete().catch(() => {}), 5000);
      return;
    }
  }

  if (cfg.antispam?.enabled) {
    const key = `${message.guild.id}:${message.author.id}`;
    if (!spamTracker[key]) spamTracker[key] = { count: 0, msgs: [], timer: null };
    const t = spamTracker[key];
    t.count++; t.msgs.push(message.id);
    clearTimeout(t.timer);
    t.timer = setTimeout(() => { delete spamTracker[key]; }, 5000);
    if (t.count >= (cfg.antispam.limit || 5)) {
      for (const id of t.msgs) message.channel.messages.cache.get(id)?.delete().catch(() => {});
      delete spamTracker[key];
      const w = await message.channel.send(`${message.author} ❌ Slow down! You're spamming!`);
      setTimeout(() => w.delete().catch(() => {}), 5000);
      return;
    }
  }

  if (cfg.caps?.enabled && message.content.length > 8) {
    const upper = (message.content.match(/[A-Z]/g) || []).length;
    const total = (message.content.match(/[a-zA-Z]/g) || []).length;
    if (total > 0 && (upper / total) * 100 >= (cfg.caps.percent || 70)) {
      await message.delete().catch(() => {});
      const w = await message.channel.send(`${message.author} ❌ Please don't use excessive caps!`);
      setTimeout(() => w.delete().catch(() => {}), 5000);
    }
  }
};
