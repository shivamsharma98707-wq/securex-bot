const { EmbedBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');

module.exports.commands = [
  {
    name: 'lock',
    description: 'Lock a channel',
    execute: async (message, args) => {
      if (!message.member.permissions.has(PermissionFlagsBits.ManageChannels)) return message.reply('❌ You need `Manage Channels` permission!');
      const ch = message.mentions.channels.first() || message.channel;
      const reason = args.filter(a => !a.startsWith('<')).join(' ') || 'No reason provided';
      await ch.permissionOverwrites.edit(message.guild.roles.everyone, { SendMessages: false });
      await message.reply({ embeds: [new EmbedBuilder().setColor(0xED4245).setTitle('🔒 Channel Locked').addFields({ name: 'Channel', value: `${ch}`, inline: true }, { name: 'Reason', value: reason }).setTimestamp()] });
    }
  },
  {
    name: 'unlock',
    description: 'Unlock a channel',
    execute: async (message, args) => {
      if (!message.member.permissions.has(PermissionFlagsBits.ManageChannels)) return message.reply('❌ You need `Manage Channels` permission!');
      const ch = message.mentions.channels.first() || message.channel;
      await ch.permissionOverwrites.edit(message.guild.roles.everyone, { SendMessages: null });
      await message.reply({ embeds: [new EmbedBuilder().setColor(0x57F287).setTitle('🔓 Channel Unlocked').setDescription(`${ch} has been unlocked.`).setTimestamp()] });
    }
  },
  {
    name: 'lockall',
    description: 'Lock all text channels',
    execute: async (message, args) => {
      if (!message.member.permissions.has(PermissionFlagsBits.ManageChannels)) return message.reply('❌ You need `Manage Channels` permission!');
      const reason = args.join(' ') || 'Server Lockdown';
      const channels = message.guild.channels.cache.filter(c => c.type === ChannelType.GuildText);
      let count = 0;
      for (const [, ch] of channels) {
        try { await ch.permissionOverwrites.edit(message.guild.roles.everyone, { SendMessages: false }); count++; } catch {}
      }
      await message.reply({ embeds: [new EmbedBuilder().setColor(0xED4245).setTitle('🔒 Server Lockdown').setDescription(`Locked **${count}** channels.\nReason: ${reason}`).setTimestamp()] });
    }
  },
  {
    name: 'unlockall',
    description: 'Unlock all text channels',
    execute: async (message, args) => {
      if (!message.member.permissions.has(PermissionFlagsBits.ManageChannels)) return message.reply('❌ You need `Manage Channels` permission!');
      const channels = message.guild.channels.cache.filter(c => c.type === ChannelType.GuildText);
      let count = 0;
      for (const [, ch] of channels) {
        try { await ch.permissionOverwrites.edit(message.guild.roles.everyone, { SendMessages: null }); count++; } catch {}
      }
      await message.reply({ embeds: [new EmbedBuilder().setColor(0x57F287).setTitle('🔓 Server Unlocked').setDescription(`Unlocked **${count}** channels.`).setTimestamp()] });
    }
  }
];
