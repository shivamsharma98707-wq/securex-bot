const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports.commands = [
  {
    name: 'embed',
    description: 'Send a custom embed',
    execute: async (message, args) => {
      if (!message.member.permissions.has(PermissionFlagsBits.ManageMessages)) return message.reply('❌ You need `Manage Messages` permission!');
      const channel = message.mentions.channels.first() || message.channel;
      const content = args.filter(a => !a.startsWith('<#')).join(' ');
      const parts = content.split('|');
      if (parts.length < 2) return message.reply('❌ Usage: `!embed [#channel] <title> | <description>`\nExample: `!embed #general Welcome! | This is our server!`');
      const title = parts[0].trim();
      const description = parts.slice(1).join('|').trim();
      const embed = new EmbedBuilder().setColor(0x00B0F4).setTitle(title).setDescription(description)
        .setFooter({ text: `Posted by ${message.author.tag}` }).setTimestamp();
      await channel.send({ embeds: [embed] });
      if (channel.id !== message.channel.id) await message.reply(`✅ Embed sent to ${channel}!`);
      await message.delete().catch(() => {});
    }
  }
];
