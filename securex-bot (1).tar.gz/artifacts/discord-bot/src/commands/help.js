const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder, StringSelectMenuOptionBuilder } = require('discord.js');
const colors = require('../utils/colors');

const categories = [
  { label: '🛡️ Anti-Nuke', value: 'antinuke', description: 'Server nuke protection', commands: ['antinuke on', 'antinuke off', 'antinuke whitelist @user', 'antinuke status'] },
  { label: '🔨 Moderation', value: 'moderation', description: 'Server moderation commands', commands: ['ban @user [reason]', 'unban <id>', 'kick @user [reason]', 'mute @user <time>', 'unmute @user', 'warn @user <reason>', 'warnings @user', 'clearwarns @user', 'purge <amount>', 'slowmode <seconds>', 'nick @user <nickname>'] },
  { label: '📋 Logging', value: 'logging', description: 'Server event logging', commands: ['logging set #channel', 'logging off', 'logging status'] },
  { label: '🎨 Custom Role', value: 'customrole', description: 'Custom role management', commands: ['crole create <name> [color]', 'crole delete @role', 'crole color @role <hex>', 'crole name @role <name>', 'crole give @user @role', 'crole remove @user @role'] },
  { label: '🔒 Lock Role', value: 'lockrole', description: 'Lock/unlock channels', commands: ['lock [#channel]', 'unlock [#channel]', 'lockall [reason]', 'unlockall'] },
  { label: '📝 Embed', value: 'embed', description: 'Create and send embeds', commands: ['embed <#channel> <title> | <description>'] },
  { label: '🤖 Autorole', value: 'autorole', description: 'Auto role on join', commands: ['autorole set @role', 'autorole remove @role', 'autorole list'] },
  { label: '✏️ Autonick', value: 'autonick', description: 'Auto nickname on join', commands: ['autonick set <pattern>', 'autonick remove', 'autonick reset @user'] },
  { label: '🔧 Utility', value: 'utility', description: 'Useful server utilities', commands: ['serverinfo', 'userinfo [@user]', 'avatar [@user]', 'ping', 'botinfo', 'roleinfo @role', 'membercount', 'invite'] },
  { label: '⚙️ Automod', value: 'automod', description: 'Auto moderation system', commands: ['automod badwords on/off [words]', 'automod antilink on/off', 'automod antispam on/off [limit]', 'automod caps on/off [%]', 'automod status'] },
  { label: '💬 Auto Responder', value: 'autoresponder', description: 'Auto response triggers', commands: ['ar add <trigger> | <response>', 'ar remove <trigger>', 'ar list'] },
  { label: '🎉 Giveaway', value: 'giveaway', description: 'Giveaway management', commands: ['gstart <duration> <winners> <prize>', 'gend <messageId>', 'greroll <messageId>', 'glist'] },
  { label: '🎮 Fun', value: 'fun', description: 'Fun commands', commands: ['8ball <question>', 'coinflip', 'dice [sides]', 'joke', 'roast @user', 'compliment @user', 'wyr', 'rps <rock/paper/scissors>'] },
];

async function sendHelp(message) {
  const embed = new EmbedBuilder()
    .setColor(0x00B0F4)
    .setTitle('💙 SecureX Bot — Help Menu')
    .setDescription(`**Prefix:** \`!\`\n**Total Modules:** ${categories.length}\n\n> Select a category from the dropdown below to see commands.`)
    .setThumbnail(message.client.user.displayAvatarURL())
    .setFooter({ text: 'SecureX Bot', iconURL: message.client.user.displayAvatarURL() })
    .setTimestamp();

  const select = new StringSelectMenuBuilder()
    .setCustomId('help_select')
    .setPlaceholder('📂 Select a category...')
    .addOptions(categories.map(c => new StringSelectMenuOptionBuilder().setLabel(c.label).setValue(c.value).setDescription(c.description)));

  const row = new ActionRowBuilder().addComponents(select);
  const msg = await message.reply({ embeds: [embed], components: [row] });

  const collector = msg.createMessageComponentCollector({ time: 120000 });
  collector.on('collect', async interaction => {
    if (interaction.user.id !== message.author.id) {
      return interaction.reply({ content: '❌ Only the command user can use this menu!', ephemeral: true });
    }

    if (interaction.isStringSelectMenu()) {
      const cat = categories.find(c => c.value === interaction.values[0]);
      const catEmbed = new EmbedBuilder()
        .setColor(0x00B0F4)
        .setTitle(`${cat.label} Commands`)
        .setDescription(cat.commands.map(c => `\`!${c}\``).join('\n'))
        .setFooter({ text: 'SecureX Bot • Use !help for main menu', iconURL: message.client.user.displayAvatarURL() })
        .setTimestamp();

      const backBtn = new ButtonBuilder().setCustomId('help_back').setLabel('◀ Back').setStyle(ButtonStyle.Secondary);
      const newSelect = new StringSelectMenuBuilder()
        .setCustomId('help_select')
        .setPlaceholder('📂 Select another category...')
        .addOptions(categories.map(c => new StringSelectMenuOptionBuilder().setLabel(c.label).setValue(c.value).setDescription(c.description)));

      await interaction.update({ embeds: [catEmbed], components: [new ActionRowBuilder().addComponents(newSelect), new ActionRowBuilder().addComponents(backBtn)] });
    } else if (interaction.isButton() && interaction.customId === 'help_back') {
      await interaction.update({ embeds: [embed], components: [row] });
    }
  });

  collector.on('end', () => { msg.edit({ components: [] }).catch(() => {}); });
}

module.exports.commands = [
  {
    name: 'help',
    aliases: ['h', 'commands'],
    description: 'Show all commands',
    execute: sendHelp
  }
];
