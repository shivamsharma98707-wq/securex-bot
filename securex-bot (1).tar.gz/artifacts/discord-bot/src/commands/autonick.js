const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuild, setGuild } = require('../utils/db');

module.exports.commands = [
  {
    name: 'autonick',
    description: 'Auto nickname for new members',
    execute: async (message, args) => {
      if (!message.member.permissions.has(PermissionFlagsBits.ManageNicknames)) return message.reply('❌ You need `Manage Nicknames` permission!');
      const sub = args[0]?.toLowerCase();
      const cfg = getGuild('autonick', message.guildId);
      if (sub === 'set') {
        const pattern = args.slice(1).join(' ');
        if (!pattern) return message.reply('❌ Usage: `!autonick set <pattern>`\nVariables: `{user}` = username, `{number}` = random number');
        cfg.pattern = pattern;
        setGuild('autonick', message.guildId, cfg);
        await message.reply({ embeds: [new EmbedBuilder().setColor(0x57F287).setTitle('✏️ Autonick Set').addFields({ name: 'Pattern', value: pattern }, { name: 'Example', value: pattern.replace('{user}', 'John').replace('{number}', '1234') }).setTimestamp()] });
      } else if (sub === 'remove' || sub === 'off') {
        cfg.pattern = null;
        setGuild('autonick', message.guildId, cfg);
        await message.reply({ embeds: [new EmbedBuilder().setColor(0x57F287).setTitle('✅ Autonick Disabled').setTimestamp()] });
      } else if (sub === 'reset') {
        const user = message.mentions.users.first();
        if (!user) return message.reply('❌ Usage: `!autonick reset @user`');
        const member = message.guild.members.cache.get(user.id);
        if (!member) return message.reply('❌ User not found!');
        await member.setNickname(null);
        await message.reply({ embeds: [new EmbedBuilder().setColor(0x57F287).setTitle('✅ Nickname Reset').setDescription(`${user.tag}'s nickname has been reset.`).setTimestamp()] });
      } else {
        await message.reply('❌ Usage: `!autonick set <pattern>` | `!autonick remove` | `!autonick reset @user`');
      }
    }
  }
];

module.exports.onMemberJoin = async function(member) {
  const cfg = getGuild('autonick', member.guild.id);
  if (!cfg.pattern) return;
  const nick = cfg.pattern.replace('{user}', member.user.username).replace('{number}', Math.floor(Math.random() * 9999));
  member.setNickname(nick.slice(0, 32)).catch(() => {});
};
