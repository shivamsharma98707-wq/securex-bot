const { EmbedBuilder } = require('discord.js');

module.exports.commands = [
  {
    name: 'serverinfo',
    aliases: ['si', 'server'],
    description: 'Server information',
    execute: async (message) => {
      const g = message.guild;
      await g.members.fetch();
      const embed = new EmbedBuilder().setColor(0x00B0F4).setTitle(`📊 ${g.name}`)
        .setThumbnail(g.iconURL({ dynamic: true }))
        .addFields(
          { name: '👑 Owner', value: `<@${g.ownerId}>`, inline: true },
          { name: '📅 Created', value: `<t:${Math.floor(g.createdTimestamp / 1000)}:R>`, inline: true },
          { name: '👥 Members', value: `${g.memberCount}`, inline: true },
          { name: '📢 Channels', value: `${g.channels.cache.size}`, inline: true },
          { name: '🎭 Roles', value: `${g.roles.cache.size}`, inline: true },
          { name: '😀 Emojis', value: `${g.emojis.cache.size}`, inline: true },
          { name: '💎 Boost Level', value: `Level ${g.premiumTier}`, inline: true },
          { name: '🚀 Boosts', value: `${g.premiumSubscriptionCount || 0}`, inline: true },
          { name: '🪪 ID', value: g.id, inline: true },
        ).setFooter({ text: `Requested by ${message.author.tag}` }).setTimestamp();
      await message.reply({ embeds: [embed] });
    }
  },
  {
    name: 'userinfo',
    aliases: ['ui', 'whois'],
    description: 'User information',
    execute: async (message) => {
      const user = message.mentions.users.first() || message.author;
      const member = message.guild.members.cache.get(user.id);
      const embed = new EmbedBuilder().setColor(0x00B0F4).setTitle(`👤 ${user.tag}`)
        .setThumbnail(user.displayAvatarURL({ dynamic: true }))
        .addFields(
          { name: '🪪 ID', value: user.id, inline: true },
          { name: '🤖 Bot', value: user.bot ? 'Yes' : 'No', inline: true },
          { name: '📅 Joined Discord', value: `<t:${Math.floor(user.createdTimestamp / 1000)}:R>`, inline: true },
        );
      if (member) embed.addFields(
        { name: '📥 Joined Server', value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>`, inline: true },
        { name: '🎭 Top Role', value: `${member.roles.highest}`, inline: true },
        { name: '🎯 Roles', value: member.roles.cache.size > 1 ? member.roles.cache.filter(r => r.id !== message.guild.id).map(r => `${r}`).join(', ').slice(0, 1024) : 'None' }
      );
      embed.setFooter({ text: `Requested by ${message.author.tag}` }).setTimestamp();
      await message.reply({ embeds: [embed] });
    }
  },
  {
    name: 'avatar',
    aliases: ['av', 'pfp'],
    description: 'Get user avatar',
    execute: async (message) => {
      const user = message.mentions.users.first() || message.author;
      await message.reply({ embeds: [new EmbedBuilder().setColor(0x00B0F4).setTitle(`🖼️ ${user.tag}'s Avatar`).setImage(user.displayAvatarURL({ dynamic: true, size: 1024 })).setFooter({ text: `ID: ${user.id}` })] });
    }
  },
  {
    name: 'ping',
    description: 'Check bot latency',
    execute: async (message) => {
      const sent = await message.reply('🏓 Pinging...');
      const ping = sent.createdTimestamp - message.createdTimestamp;
      await sent.edit({ content: '', embeds: [new EmbedBuilder().setColor(0x57F287).setTitle('🏓 Pong!').addFields({ name: '📡 Latency', value: `${ping}ms`, inline: true }, { name: '💓 API Heartbeat', value: `${Math.round(message.client.ws.ping)}ms`, inline: true }).setTimestamp()] });
    }
  },
  {
    name: 'botinfo',
    aliases: ['bot', 'info'],
    description: 'Bot information',
    execute: async (message) => {
      const client = message.client;
      await message.reply({ embeds: [new EmbedBuilder().setColor(0x00B0F4).setTitle('🤖 SecureX Bot Info').setThumbnail(client.user.displayAvatarURL())
        .addFields(
          { name: '📛 Name', value: client.user.tag, inline: true },
          { name: '🪪 ID', value: client.user.id, inline: true },
          { name: '⚡ Servers', value: `${client.guilds.cache.size}`, inline: true },
          { name: '👥 Users', value: `${client.users.cache.size}`, inline: true },
          { name: '📡 Ping', value: `${Math.round(client.ws.ping)}ms`, inline: true },
          { name: '🔧 Prefix', value: '`!`', inline: true },
          { name: '📅 Online Since', value: `<t:${Math.floor(client.readyTimestamp / 1000)}:R>`, inline: true },
        ).setFooter({ text: 'SecureX Bot' }).setTimestamp()] });
    }
  },
  {
    name: 'roleinfo',
    aliases: ['ri'],
    description: 'Role information',
    execute: async (message) => {
      const role = message.mentions.roles.first();
      if (!role) return message.reply('❌ Usage: `!roleinfo @role`');
      await message.reply({ embeds: [new EmbedBuilder().setColor(role.color || 0x00B0F4).setTitle(`🎭 ${role.name}`)
        .addFields(
          { name: '🪪 ID', value: role.id, inline: true },
          { name: '🎨 Color', value: role.hexColor, inline: true },
          { name: '📅 Created', value: `<t:${Math.floor(role.createdTimestamp / 1000)}:R>`, inline: true },
          { name: '👥 Members', value: `${role.members.size}`, inline: true },
          { name: '📌 Position', value: `${role.position}`, inline: true },
          { name: '🤖 Mentionable', value: role.mentionable ? 'Yes' : 'No', inline: true },
        ).setTimestamp()] });
    }
  },
  {
    name: 'membercount',
    aliases: ['mc'],
    description: 'Show member count',
    execute: async (message) => {
      const g = message.guild;
      await g.members.fetch();
      const bots = g.members.cache.filter(m => m.user.bot).size;
      await message.reply({ embeds: [new EmbedBuilder().setColor(0x00B0F4).setTitle('👥 Member Count').addFields({ name: '👤 Humans', value: `${g.memberCount - bots}`, inline: true }, { name: '🤖 Bots', value: `${bots}`, inline: true }, { name: '📊 Total', value: `${g.memberCount}`, inline: true }).setTimestamp()] });
    }
  },
  {
    name: 'invite',
    description: 'Get bot invite link',
    execute: async (message) => {
      const link = `https://discord.com/api/oauth2/authorize?client_id=${message.client.user.id}&permissions=8&scope=bot`;
      await message.reply({ embeds: [new EmbedBuilder().setColor(0x00B0F4).setTitle('🔗 Invite SecureX Bot').setDescription(`[Click here to invite me!](${link})`).setTimestamp()] });
    }
  }
];
