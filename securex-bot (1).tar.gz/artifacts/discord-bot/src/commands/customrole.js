const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports.commands = [
  {
    name: 'crole',
    aliases: ['customrole', 'cr'],
    description: 'Custom role management',
    execute: async (message, args) => {
      if (!message.member.permissions.has(PermissionFlagsBits.ManageRoles)) return message.reply('❌ You need `Manage Roles` permission!');
      const sub = args[0]?.toLowerCase();
      if (sub === 'create') {
        const name = args.slice(1).join(' ').split('|')[0]?.trim();
        const color = args.slice(1).join(' ').split('|')[1]?.trim() || '#99AAB5';
        if (!name) return message.reply('❌ Usage: `!crole create <name> | [color]`');
        const role = await message.guild.roles.create({ name, color, reason: `Created by ${message.author.tag}` });
        await message.reply({ embeds: [new EmbedBuilder().setColor(0x57F287).setTitle('🎨 Role Created').addFields({ name: 'Role', value: `${role}`, inline: true }, { name: 'Color', value: role.hexColor, inline: true }).setTimestamp()] });
      } else if (sub === 'delete') {
        const role = message.mentions.roles.first();
        if (!role) return message.reply('❌ Usage: `!crole delete @role`');
        const name = role.name;
        await role.delete();
        await message.reply({ embeds: [new EmbedBuilder().setColor(0x57F287).setTitle('🗑️ Role Deleted').setDescription(`Role **${name}** deleted.`).setTimestamp()] });
      } else if (sub === 'color') {
        const role = message.mentions.roles.first();
        const color = args[2];
        if (!role || !color) return message.reply('❌ Usage: `!crole color @role <#hex>`');
        await role.setColor(color);
        await message.reply({ embeds: [new EmbedBuilder().setColor(0x57F287).setTitle('🎨 Color Updated').setDescription(`${role} color → **${color}**`).setTimestamp()] });
      } else if (sub === 'name') {
        const role = message.mentions.roles.first();
        const name = args.slice(2).join(' ');
        if (!role || !name) return message.reply('❌ Usage: `!crole name @role <new name>`');
        await role.setName(name);
        await message.reply({ embeds: [new EmbedBuilder().setColor(0x57F287).setTitle('✏️ Role Renamed').setDescription(`Role renamed to **${name}**`).setTimestamp()] });
      } else if (sub === 'give') {
        const user = message.mentions.users.first();
        const role = message.mentions.roles.first();
        if (!user || !role) return message.reply('❌ Usage: `!crole give @user @role`');
        const member = message.guild.members.cache.get(user.id);
        if (!member) return message.reply('❌ User not found!');
        await member.roles.add(role);
        await message.reply({ embeds: [new EmbedBuilder().setColor(0x57F287).setTitle('✅ Role Given').setDescription(`${role} given to ${user.tag}.`).setTimestamp()] });
      } else if (sub === 'remove') {
        const user = message.mentions.users.first();
        const role = message.mentions.roles.first();
        if (!user || !role) return message.reply('❌ Usage: `!crole remove @user @role`');
        const member = message.guild.members.cache.get(user.id);
        if (!member) return message.reply('❌ User not found!');
        await member.roles.remove(role);
        await message.reply({ embeds: [new EmbedBuilder().setColor(0x57F287).setTitle('✅ Role Removed').setDescription(`${role} removed from ${user.tag}.`).setTimestamp()] });
      } else {
        await message.reply('❌ Usage: `!crole create/delete/color/name/give/remove`');
      }
    }
  }
];
