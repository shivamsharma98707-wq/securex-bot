const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuild, setGuild } = require('../utils/db');

module.exports.commands = [
  {
    name: 'autorole',
    aliases: ['ar-role'],
    description: 'Auto role on member join',
    execute: async (message, args) => {
      if (!message.member.permissions.has(PermissionFlagsBits.ManageRoles)) return message.reply('❌ You need `Manage Roles` permission!');
      const sub = args[0]?.toLowerCase();
      const cfg = getGuild('autorole', message.guildId);
      if (!cfg.roles) cfg.roles = [];
      if (sub === 'set') {
        const role = message.mentions.roles.first();
        if (!role) return message.reply('❌ Usage: `!autorole set @role`');
        if (cfg.roles.includes(role.id)) return message.reply('❌ This role is already in autorole list!');
        cfg.roles.push(role.id);
        setGuild('autorole', message.guildId, cfg);
        await message.reply({ embeds: [new EmbedBuilder().setColor(0x57F287).setTitle('✅ Autorole Added').setDescription(`${role} will now be given to new members.`).setTimestamp()] });
      } else if (sub === 'remove') {
        const role = message.mentions.roles.first();
        if (!role) return message.reply('❌ Usage: `!autorole remove @role`');
        cfg.roles = cfg.roles.filter(id => id !== role.id);
        setGuild('autorole', message.guildId, cfg);
        await message.reply({ embeds: [new EmbedBuilder().setColor(0x57F287).setTitle('✅ Autorole Removed').setDescription(`${role} removed from autoroles.`).setTimestamp()] });
      } else if (sub === 'list') {
        const roles = cfg.roles.map(id => `<@&${id}>`).join(', ') || 'No autoroles set.';
        await message.reply({ embeds: [new EmbedBuilder().setColor(0x5865F2).setTitle('🤖 Autoroles').setDescription(roles).setTimestamp()] });
      } else {
        await message.reply('❌ Usage: `!autorole set/remove/list`');
      }
    }
  }
];

module.exports.onMemberJoin = async function(member) {
  const cfg = getGuild('autorole', member.guild.id);
  if (!cfg.roles?.length) return;
  for (const roleId of cfg.roles) {
    const role = member.guild.roles.cache.get(roleId);
    if (role) member.roles.add(role).catch(() => {});
  }
};
